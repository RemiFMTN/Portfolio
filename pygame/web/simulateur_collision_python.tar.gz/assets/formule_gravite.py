import math

G = 1

def formule_gravite(c1, c2):

    dx = c2.x - c1.x
    dy = c2.y - c1.y

    distance = math.sqrt(dx**2 + dy**2)

    distance = max(distance, 1)

    m1 = c1.masse
    m2 = c2.masse
    force = G * m1 * m2 / distance**2

    nx = dx / distance
    ny = dy / distance

    Fx = force * nx
    Fy = force * ny

    return Fx, Fy