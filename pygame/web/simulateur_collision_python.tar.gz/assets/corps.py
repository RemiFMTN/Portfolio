import pygame


class Corps:

    def __init__(self, x, y, vx, vy, rayon, masse, couleur):

        self.x = x
        self.y = y

        self.vx = vx
        self.vy = vy

        self.rayon = rayon
        self.masse = masse

        self.couleur = pygame.Color(couleur)

        self.densite = masse / (rayon ** 2)

        self.trace = []

    # =========================================
    # ABSORPTION
    # =========================================

    def absorb(self, other):

        total_mass = self.masse + other.masse

        if total_mass <= 0:
            return

        # conservation quantité de mouvement

        self.vx = (
            self.vx * self.masse
            + other.vx * other.masse
        ) / total_mass

        self.vy = (
            self.vy * self.masse
            + other.vy * other.masse
        ) / total_mass

        self.masse = total_mass

        # conservation densité

        self.rayon = (self.masse / self.densite) ** 0.5

    # =========================================
    # REBOND
    # =========================================

    def rebond(self, other):

        dx = other.x - self.x
        dy = other.y - self.y

        distance = (dx ** 2 + dy ** 2) ** 0.5

        if distance == 0:
            return

        # normale

        nx = dx / distance
        ny = dy / distance

        # vitesse relative

        dvx = self.vx - other.vx
        dvy = self.vy - other.vy

        # impulsion

        impulse = (
            2 * (dvx * nx + dvy * ny)
        ) / (self.masse + other.masse)

        # update vitesses

        self.vx -= impulse * other.masse * nx
        self.vy -= impulse * other.masse * ny

        other.vx += impulse * self.masse * nx
        other.vy += impulse * self.masse * ny

    # =========================================
    # UPDATE
    # =========================================

    def update(self, dt):

        self.x += self.vx * dt
        self.y += self.vy * dt

        # ajout trace

        self.trace.append((self.x, self.y))

        # limite taille trace

        if len(self.trace) > 200:
            self.trace.pop(0)

    # =========================================
    # DRAW
    # =========================================

    def draw(self, screen, camera):

        screen_x, screen_y = camera.world_to_screen(
            self.x,
            self.y
        )

        radius = max(
            1,
            int(self.rayon * camera.zoom)
        )

        # =========================================
        # TRACE
        # =========================================

        for i, pos in enumerate(self.trace):

            tx, ty = camera.world_to_screen(
                pos[0],
                pos[1]
            )

            alpha = int(
                255 * (i / len(self.trace))
            )

            color = pygame.Color(self.couleur)

            color.a = alpha

            surface = pygame.Surface(
                (4, 4),
                pygame.SRCALPHA
            )

            pygame.draw.circle(
                surface,
                color,
                (2, 2),
                2
            )

            screen.blit(
                surface,
                (int(tx) - 2, int(ty) - 2)
            )

        # =========================================
        # CORPS
        # =========================================

        pygame.draw.circle(
            screen,
            self.couleur,
            (int(screen_x), int(screen_y)),
            radius
        )