class Camera:

    def __init__(self, width, height):

        self.width = width
        self.height = height

        # position caméra dans le monde
        self.x = 0
        self.y = 0

        # zoom
        self.zoom = 1.0

    # =========================================
    # Convertit coordonnées monde -> écran
    # =========================================

    def world_to_screen(self, x, y):

        screen_x = (x - self.x) * self.zoom + self.width / 2
        screen_y = (y - self.y) * self.zoom + self.height / 2

        return screen_x, screen_y

    # =========================================
    # Convertit coordonnées écran -> monde
    # =========================================

    def screen_to_world(self, screen_x, screen_y):

        world_x = (screen_x - self.width / 2) / self.zoom + self.x
        world_y = (screen_y - self.height / 2) / self.zoom + self.y

        return world_x, world_y

    # =========================================
    # Déplacement caméra
    # =========================================

    def move(self, dx, dy):

        self.x += dx
        self.y += dy

    # =========================================
    # Zoom caméra
    # =========================================

    def apply_zoom(self, zoom_factor):

        self.zoom *= zoom_factor

        # limite min/max
        self.zoom = max(0.05, min(self.zoom, 20))

    # =========================================
    # Suivre un corps
    # =========================================

    def follow(self, body):

        self.x = body.x
        self.y = body.y