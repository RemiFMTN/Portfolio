import asyncio
import pygame

from camera import Camera
from corps import Corps
import formule_gravite as gravite

pygame.init()

# =========================================
# ÉCRA

WIDTH, HEIGHT = 1080, 720

screen = pygame.display.set_mode((WIDTH, HEIGHT))

clock = pygame.time.Clock()

# =========================================
# CAMER

camera = Camera(WIDTH, HEIGHT)

# =========================================
# CENTRE MOND

centre_x = 0
centre_y = 0

# =========================================
# ÉCHELL

# 1 UA = 200 pixels
AU = 200

# =========================================
# TEMP

# accélération du temps
TIME_SCALE = 1
time_scale_str = str(TIME_SCALE)
time_scale_active = False
time_scale_edit = ""

ui_font = pygame.font.Font(None, 24)
minus5_rect = pygame.Rect(20, 20, 40, 30)
minus_rect = pygame.Rect(70, 20, 30, 30)
input_rect = pygame.Rect(110, 20, 90, 30)
plus_rect = pygame.Rect(210, 20, 30, 30)
plus5_rect = pygame.Rect(250, 20, 40, 30)
reset_rect = pygame.Rect(300, 20, 70, 30)

# =========================================
# GRAVIT

GRAVITY_SCALE = 1.0
gravity_scale_str = str(GRAVITY_SCALE)
gravity_scale_active = False
gravity_scale_edit = ""

g_minus5_rect = pygame.Rect(20, 60, 40, 30)
g_minus_rect = pygame.Rect(70, 60, 30, 30)
g_input_rect = pygame.Rect(110, 60, 90, 30)
g_plus_rect = pygame.Rect(210, 60, 30, 30)
g_plus5_rect = pygame.Rect(250, 60, 40, 30)

dragging_body = None
drag_offset = (0.0, 0.0)

# =========================================
# DONNÉE

soleil_masse = 332943

# =========================================
# ORBITE

mercure_r = AU * 0.387098
venus_r = AU * 0.723331
terre_r = AU * 1.0
mars_r = AU * 1.523662
jupiter_r = AU * 5.203363
saturne_r = AU * 9.537070
uranus_r = AU * 19.191263
neptune_r = AU * 30.068963
pluton_r = AU * 39.482116

# =========================================
# EXCENTRICITÉ

mercure_e = 0.205630
venus_e = 0.006772
terre_e = 0.016710
mars_e = 0.093412
jupiter_e = 0.048392
saturne_e = 0.054150
uranus_e = 0.047168
neptune_e = 0.008590
pluton_e = 0.248807

# =========================================
# VITESSES ORBITALE

def orbital_velocity(r):
    return (gravite.G * soleil_masse / r) ** 0.5

# =========================================
# POSITION AU PÉRIHÉLI

def perihelion(r, e):
    return r * (1 - e)

# =========================================
# VITESSE AU PÉRIHÉLI

def perihelion_velocity(r, e):

    return orbital_velocity(r) * ((1 + e) / (1 - e)) ** 0.5

# =========================================
# CORP

def create_bodies():
    return [

        # Soleil
        Corps(
            centre_x,
            centre_y,
            0,
            0,
            30,
            soleil_masse,
            "#fffeb1"
        ),

        # Mercure
        Corps(
            perihelion(mercure_r, mercure_e),
            0,
            0,
            perihelion_velocity(mercure_r, mercure_e),
            4,
            0.05527,
            "#c8c8c8"
        ),

        # Vénus
        Corps(
            perihelion(venus_r, venus_e),
            0,
            0,
            perihelion_velocity(venus_r, venus_e),
            6,
            0.8150,
            "#f89a52"
        ),

        # Terre
        Corps(
            perihelion(terre_r, terre_e),
            0,
            0,
            perihelion_velocity(terre_r, terre_e),
            10,
            1,
            "#4343ff"
        ),

        # Mars
        Corps(
            perihelion(mars_r, mars_e),
            0,
            0,
            perihelion_velocity(mars_r, mars_e),
            5,
            0.1074,
            "#ff4411"
        ),

        # Jupiter
        Corps(
            perihelion(jupiter_r, jupiter_e),
            0,
            0,
            perihelion_velocity(jupiter_r, jupiter_e),
            15,
            317.8,
            "#d2b48c"
        ),

        # Saturne
        Corps(
            perihelion(saturne_r, saturne_e),
            0,
            0,
            perihelion_velocity(saturne_r, saturne_e),
            12,
            95.15,
            "#f0e68c"
        ),

        # Uranus
        Corps(
            perihelion(uranus_r, uranus_e),
            0,
            0,
            perihelion_velocity(uranus_r, uranus_e),
            11,
            14.54,
            "#add8e6"
        ),

        # Neptune
        Corps(
            perihelion(neptune_r, neptune_e),
            0,
            0,
            perihelion_velocity(neptune_r, neptune_e),
            10,
            17.15,
            "#4169e1"
        ),

        # Pluton
        Corps(
            -perihelion(pluton_r, pluton_e),
            0,
            0,
            -perihelion_velocity(pluton_r, pluton_e),
            3,
            0.002,
            "#c0c0c0"
        )
    ]


corps = create_bodies()

# =========================================
# CAMERA INI

camera.follow(corps[0])

# =========================================
# DISTANC

def distance(c1, c2):

    dx = c2.x - c1.x
    dy = c2.y - c1.y

    return (dx**2 + dy**2) ** 0.5

# =========================================
# BOUCLE PRINCIPAL

async def main():
    global TIME_SCALE
    global time_scale_str
    global time_scale_active
    global time_scale_edit
    global GRAVITY_SCALE
    global gravity_scale_str
    global gravity_scale_active
    global gravity_scale_edit
    global corps
    global dragging_body
    global drag_offset

    running = True

    while running:

        # =========================================
        # DT

        dt = clock.tick(120) / 1000
        sim_dt = dt * TIME_SCALE

        # =========================================
        # INPUT CLAVIER

        keys = pygame.key.get_pressed()

        camera_speed = 500 / camera.zoom * dt

        if keys[pygame.K_q]:
            camera.move(-camera_speed, 0)

        if keys[pygame.K_d]:
            camera.move(camera_speed, 0)

        if keys[pygame.K_z]:
            camera.move(0, -camera_speed)

        if keys[pygame.K_s]:
            camera.move(0, camera_speed)

        # =========================================
        # EVENTS

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button != 1:
                    continue
                if reset_rect.collidepoint(event.pos):
                    corps = create_bodies()
                    camera.follow(corps[0])
                    dragging_body = None
                    continue
                if minus5_rect.collidepoint(event.pos):
                    TIME_SCALE = max(1, TIME_SCALE - 5)
                    time_scale_str = str(TIME_SCALE)
                elif minus_rect.collidepoint(event.pos):
                    TIME_SCALE = max(1, TIME_SCALE - 1)
                    time_scale_str = str(TIME_SCALE)
                elif plus_rect.collidepoint(event.pos):
                    TIME_SCALE = TIME_SCALE + 1
                    time_scale_str = str(TIME_SCALE)
                elif plus5_rect.collidepoint(event.pos):
                    TIME_SCALE = TIME_SCALE + 5
                    time_scale_str = str(TIME_SCALE)
                elif input_rect.collidepoint(event.pos):
                    time_scale_active = True
                    time_scale_edit = ""
                    gravity_scale_active = False
                else:
                    time_scale_active = False
                    gravity_scale_active = False
                    for body in reversed(corps):
                        sx, sy = camera.world_to_screen(body.x, body.y)
                        radius = max(1, body.rayon * camera.zoom)
                        dx = event.pos[0] - sx
                        dy = event.pos[1] - sy
                        if dx * dx + dy * dy <= radius * radius:
                            dragging_body = body
                            wx, wy = camera.screen_to_world(*event.pos)
                            drag_offset = (body.x - wx, body.y - wy)
                            break

                if g_minus5_rect.collidepoint(event.pos):
                    GRAVITY_SCALE = max(0.1, GRAVITY_SCALE - 5)
                    gravity_scale_str = str(GRAVITY_SCALE)
                    gravite.G = GRAVITY_SCALE
                elif g_minus_rect.collidepoint(event.pos):
                    GRAVITY_SCALE = max(0.1, GRAVITY_SCALE - 1)
                    gravity_scale_str = str(GRAVITY_SCALE)
                    gravite.G = GRAVITY_SCALE
                elif g_plus_rect.collidepoint(event.pos):
                    GRAVITY_SCALE = GRAVITY_SCALE + 1
                    gravity_scale_str = str(GRAVITY_SCALE)
                    gravite.G = GRAVITY_SCALE
                elif g_plus5_rect.collidepoint(event.pos):
                    GRAVITY_SCALE = GRAVITY_SCALE + 5
                    gravity_scale_str = str(GRAVITY_SCALE)
                    gravite.G = GRAVITY_SCALE
                elif g_input_rect.collidepoint(event.pos):
                    gravity_scale_active = True
                    gravity_scale_edit = ""
                    time_scale_active = False

            if event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:
                    dragging_body = None

            if event.type == pygame.KEYDOWN and time_scale_active:
                if event.key == pygame.K_RETURN:
                    try:
                        value = float(time_scale_edit) if time_scale_edit else float(time_scale_str)
                        TIME_SCALE = max(1, value)
                        time_scale_str = str(TIME_SCALE)
                    except ValueError:
                        time_scale_str = str(TIME_SCALE)
                    time_scale_active = False
                elif event.key == pygame.K_BACKSPACE:
                    time_scale_edit = time_scale_edit[:-1]
                else:
                    if event.unicode.isdigit() or event.unicode == ".":
                        time_scale_edit += event.unicode

            if event.type == pygame.KEYDOWN and gravity_scale_active:
                if event.key == pygame.K_RETURN:
                    try:
                        value = float(gravity_scale_edit) if gravity_scale_edit else float(gravity_scale_str)
                        GRAVITY_SCALE = max(0.1, value)
                        gravity_scale_str = str(GRAVITY_SCALE)
                        gravite.G = GRAVITY_SCALE
                    except ValueError:
                        gravity_scale_str = str(GRAVITY_SCALE)
                    gravity_scale_active = False
                elif event.key == pygame.K_BACKSPACE:
                    gravity_scale_edit = gravity_scale_edit[:-1]
                else:
                    if event.unicode.isdigit() or event.unicode == ".":
                        gravity_scale_edit += event.unicode

            # =========================================
            # ZOOM

            if event.type == pygame.MOUSEWHEEL:

                if event.y > 0:
                    camera.apply_zoom(1.1)

                if event.y < 0:
                    camera.apply_zoom(0.9)

        # =========================================
        # FOND

        screen.fill((10, 10, 20))

        # =========================================
        # UI TIME SCALE

        pygame.draw.rect(screen, (40, 40, 50), minus5_rect, border_radius=4)
        pygame.draw.rect(screen, (40, 40, 50), minus_rect, border_radius=4)
        input_color = (60, 60, 80) if time_scale_active else (30, 30, 40)
        pygame.draw.rect(screen, input_color, input_rect, border_radius=4)
        pygame.draw.rect(screen, (40, 40, 50), plus_rect, border_radius=4)
        pygame.draw.rect(screen, (40, 40, 50), plus5_rect, border_radius=4)
        pygame.draw.rect(screen, (70, 45, 45), reset_rect, border_radius=4)

        label = ui_font.render("Temps", True, (200, 200, 210))
        screen.blit(label, (20, 2))

        minus5_text = ui_font.render("-5", True, (230, 230, 230))
        minus_text = ui_font.render("-", True, (230, 230, 230))
        plus_text = ui_font.render("+", True, (230, 230, 230))
        plus5_text = ui_font.render("+5", True, (230, 230, 230))
        screen.blit(minus5_text, minus5_text.get_rect(center=minus5_rect.center))
        screen.blit(minus_text, minus_text.get_rect(center=minus_rect.center))
        screen.blit(plus_text, plus_text.get_rect(center=plus_rect.center))
        screen.blit(plus5_text, plus5_text.get_rect(center=plus5_rect.center))

        reset_text = ui_font.render("Reset", True, (230, 230, 230))
        screen.blit(reset_text, reset_text.get_rect(center=reset_rect.center))

        display_value = time_scale_edit if time_scale_active else time_scale_str
        value_text = ui_font.render(display_value, True, (230, 230, 230))
        screen.blit(value_text, value_text.get_rect(center=input_rect.center))

        # =========================================
        # UI GRAVITY SCALE

        pygame.draw.rect(screen, (40, 40, 50), g_minus5_rect, border_radius=4)
        pygame.draw.rect(screen, (40, 40, 50), g_minus_rect, border_radius=4)
        g_input_color = (60, 60, 80) if gravity_scale_active else (30, 30, 40)
        pygame.draw.rect(screen, g_input_color, g_input_rect, border_radius=4)
        pygame.draw.rect(screen, (40, 40, 50), g_plus_rect, border_radius=4)
        pygame.draw.rect(screen, (40, 40, 50), g_plus5_rect, border_radius=4)

        g_label = ui_font.render("Gravite", True, (200, 200, 210))
        screen.blit(g_label, (20, 42))

        g_minus5_text = ui_font.render("-5", True, (230, 230, 230))
        g_minus_text = ui_font.render("-", True, (230, 230, 230))
        g_plus_text = ui_font.render("+", True, (230, 230, 230))
        g_plus5_text = ui_font.render("+5", True, (230, 230, 230))
        screen.blit(g_minus5_text, g_minus5_text.get_rect(center=g_minus5_rect.center))
        screen.blit(g_minus_text, g_minus_text.get_rect(center=g_minus_rect.center))
        screen.blit(g_plus_text, g_plus_text.get_rect(center=g_plus_rect.center))
        screen.blit(g_plus5_text, g_plus5_text.get_rect(center=g_plus5_rect.center))

        g_display_value = gravity_scale_edit if gravity_scale_active else gravity_scale_str
        g_value_text = ui_font.render(g_display_value, True, (230, 230, 230))
        screen.blit(g_value_text, g_value_text.get_rect(center=g_input_rect.center))

        # =========================================
        # CALCUL DES FORCES

        accelerations = []

        for c1 in corps:

            Fx_total = 0
            Fy_total = 0

            for c2 in corps:

                if c1 != c2:

                    Fx, Fy = gravite.formule_gravite(c1, c2)

                    Fx_total += Fx
                    Fy_total += Fy

            ax = Fx_total / c1.masse
            ay = Fy_total / c1.masse

            accelerations.append((ax, ay))

        # =========================================
        # UPDATE VITESSES

        for i, c in enumerate(corps):

            ax, ay = accelerations[i]

            c.vx += ax * sim_dt
            c.vy += ay * sim_dt

        # =========================================
        # UPDATE POSITIONS

        for c in corps:

            c.update(sim_dt)

        if dragging_body is not None:
            mx, my = pygame.mouse.get_pos()
            wx, wy = camera.screen_to_world(mx, my)
            dragging_body.x = wx + drag_offset[0]
            dragging_body.y = wy + drag_offset[1]
            dragging_body.vx = 0
            dragging_body.vy = 0

        # =========================================
        # AFFICHAGE

        for c in corps:

            c.draw(screen, camera)

        # =========================================
        # UPDATE ÉCRAN

        pygame.display.flip()
        # Yield to the browser event loop for pygbag/WebAssembly
        await asyncio.sleep(0)

    pygame.quit()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except RuntimeError:
        # Pygbag already runs an event loop in the browser.
        asyncio.get_event_loop().create_task(main())